If you will need to know more, go to: https://www.unisoftdev.tech/download/mask-email
You can see more informations.
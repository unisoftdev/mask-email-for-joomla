document.addEventListener("DOMContentLoaded", function(event) { 
document.body.innerHTML = document.body.innerHTML.replace(/unisoftdevmask/g, '@');
});